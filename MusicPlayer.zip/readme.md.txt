Hey in this I am listing what all innovations I have done

1) text-color-gradient on ninja studio upon hover
2) On the corousel zooming hover effect
3) on all the hearts a zooming effect 
4) on latest release images, opacity and display of play button upon hover
5) same thing as above on popular artist section
6) the artist page is connected with href from popular artist
7) internal zooming effect in party, electronin, road trip images
8) invisible scroll bar on queue 
9) checkbox concept used in the footer for heart and play button, they change their state upon clicking
10) media query added